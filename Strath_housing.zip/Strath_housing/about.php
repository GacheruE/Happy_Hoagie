<?php include'header.php';?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="#">Home</a> / About Us</span>
    <h2>About Us</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="spacer">
<div class="row">
  <div class="col-lg-8  col-lg-offset-2">
  <img src="images/about2.jpg" class="img-responsive thumbnail"  alt="realestate">
  <h3>Business Background</h3>
  <p>Kodisha Student Housing is a newly established real estate company,aimed to provide affordable for students in strathmore university and its environs.Our website was created to give students a wide variety of options,other than hostels located around the school.</p>
  <h3>Our Mission</h3>
  <p>To provide affordable housing to students, and to ensure their safety while doing so.</p>
  <p>We are here to give you an easy transition to university life.Find your perfect house;to live alone or with friends.Interact with fully licensed Real Etate Agents, and school alumni. Find affordable housing with us today. </p>
  </div>
 
</div>
</div>
</div>

<?php include'footer.php';?>